package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.3-6';
}

sub release {
    return '7.3';
}

sub repoid {
    return '723bb6ec';
}

sub version_text {
    return '7.3-6/723bb6ec';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.3-6',
	'release' => '7.3',
	'repoid' => '723bb6ec',
    }
}

1;
