package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.2-11';
}

sub release {
    return '7.2';
}

sub repoid {
    return 'b76d3178';
}

sub version_text {
    return '7.2-11/b76d3178';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.2-11',
	'release' => '7.2',
	'repoid' => 'b76d3178',
    }
}

1;
