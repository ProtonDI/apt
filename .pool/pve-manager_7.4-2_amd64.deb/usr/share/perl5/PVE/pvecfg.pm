package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.4-2';
}

sub release {
    return '7.4';
}

sub repoid {
    return '4df3fa34';
}

sub version_text {
    return '7.4-2/4df3fa34';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.4-2',
	'release' => '7.4',
	'repoid' => '4df3fa34',
    }
}

1;
