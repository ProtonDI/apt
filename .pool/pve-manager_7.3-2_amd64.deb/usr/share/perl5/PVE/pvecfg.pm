package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.3-2';
}

sub release {
    return '7.3';
}

sub repoid {
    return '52798ad5';
}

sub version_text {
    return '7.3-2/52798ad5';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.3-2',
	'release' => '7.3',
	'repoid' => '52798ad5',
    }
}

1;
