package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.3-4';
}

sub release {
    return '7.3';
}

sub repoid {
    return 'd69b70d4';
}

sub version_text {
    return '7.3-4/d69b70d4';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.3-4',
	'release' => '7.3',
	'repoid' => 'd69b70d4',
    }
}

1;
